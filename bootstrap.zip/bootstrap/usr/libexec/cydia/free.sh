#!/bin/sh

sync
