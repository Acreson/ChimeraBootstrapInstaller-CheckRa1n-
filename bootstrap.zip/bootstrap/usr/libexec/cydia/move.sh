#!/bin/bash

shopt -s extglob nullglob

if [[ ${1:0:1} == - ]]; then
    v=$1
    shift 1
else
    v=
fi

function shift_() {
    dir=${1%/}

    if mount | grep 'on / (apfs' >/dev/null; then
        if [[ ! -d ${dir} ]]; then
            mkdir "${dir}"
            chmod 755 "${dir}"
            chown root:admin "${dir}"
        fi
        return
    fi
}

shift_ "$@"
